import {randomUUID} from 'node:crypto';import {db,hashCode,makeToken,cookieOptions,noStore} from '../../../../lib/access';
export const runtime='nodejs';
export async function POST(req:Request){try{const {code}=await req.json();if(typeof code!=='string'||!/^[A-Z0-9]{8}$/.test(code.toUpperCase()))return noStore({error:'请输入8位授权码'},400);
const id=randomUUID();const r=await db('rpc/activate_quiz_code',{method:'POST',body:JSON.stringify({p_hash:hashCode(code.toUpperCase()),p_session:id})});if(!r.ok)return noStore({error:'验证服务暂时不可用'},503);const result=await r.json();if(result?.[0]?.result!=='ok')return noStore({error:result?.[0]?.result==='used'?'授权码已被激活':'授权码无效或已禁用'},403);
const response=Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});response.headers.append('Set-Cookie',`awakening_access=${makeToken(id)}; Path=/; Max-Age=${cookieOptions().maxAge}; HttpOnly; SameSite=Lax${process.env.NODE_ENV==='production'?'; Secure':''}`);return response;
}catch{return noStore({error:'验证失败，请稍后重试'},400)}}
